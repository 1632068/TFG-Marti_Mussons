import re
import os
from subprocess import call

files = ["main.tex"]


#Copy standard files
# call(["cp", "../%s" %  "arxive_submission.bbl", "."])

comment = re.compile("(?<!\\\\)%")
graphics = re.compile("\\\\includegraphics(\[.*?\])?\{(.*?)\}")
png = re.compile("\.png$")

def process_file(match):
    (opt, file) =  list(match.groups())
    file = file[:-4] #Add hidden image path
    if 0: # png.findall(file): #Activate to convert .png images to .jpg
        file_new = png.sub(".jpg", file)
        file_new = str.replace(file_new, '/', '_')
        quality = 98
        call(["convert", "../%s" % file, "-quality", str(quality), file_new])
        return "\includegraphics%s{%s}" % (opt, file_new)
        
    else: #Just copy file otherwise
        file_new = file[3:]
        file_new = str.replace(file_new, '/', '_')
        found = False
        ending = ''
        for suffix in ['.png','.pdf','.jpg','']:
            if os.path.isfile("../%s" % file + suffix):
                call(["cp", "../%s" % file + suffix, file_new + suffix])
                found = True
                ending = suffix
        if not found:
            print('Error: File not found: ' + file)
        
        return "\includegraphics%s{%s}" % (opt, file_new + ending)
    
for filename in files:
    fout = open(filename, "w")
    with open("../%s" % filename, "r") as f:
        for line in f:
            line_split = comment.split(line)
            line_ = line_split[0] if len(line_split) == 1 \
                    else line_split[0]+"%\n"
            line_ = graphics.sub(process_file, line_)
            fout.write(line_)
    fout.close()
            
            
            
## Rename files to order them correctly


